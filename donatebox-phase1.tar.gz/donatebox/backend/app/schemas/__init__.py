"""DonateBox - Pydantic Schemas"""
